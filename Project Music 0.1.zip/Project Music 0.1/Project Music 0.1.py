import pygame

from pygame.locals import *

pygame.init()

fenetre = pygame.display.set_mode((1300,675))
pygame.display.set_caption("Project Music")

infinite = 1

do = pygame.mixer.Sound("1-do(c1).wav")
do_ = pygame.mixer.Sound("2-do#(c1s).wav")
re = pygame.mixer.Sound("3-re(d1).wav")
re_ = pygame.mixer.Sound("4-re#(d1s).wav")
mi = pygame.mixer.Sound("5-mi(e1).wav")
fa = pygame.mixer.Sound("6-fa(f1).wav")
fa_ = pygame.mixer.Sound("7-fa#(f1s).wav")
sol = pygame.mixer.Sound("8-sol(g1).wav")
sol_ = pygame.mixer.Sound("9-sol#(g1s).wav")
la = pygame.mixer.Sound("10-la(a1).wav")
la_ = pygame.mixer.Sound("11-la#(a1s).wav")
si = pygame.mixer.Sound("12-si(b1).wav")
do2 = pygame.mixer.Sound("13-do2(c2).wav")

while infinite:
    
    for event in pygame.event.get():
        if event.type == QUIT:
            infinite = 0
            
        if event.type == KEYDOWN:
            if event.key == K_e:
                do.play()
            if event.key == K_4:
                do_.play()
            if event.key == K_r:
                re.play()
            if event.key == K_5:
                re_.play()
            if event.key == K_t:
                mi.play()
            if event.key == K_y:
                fa.play()
            if event.key == K_7:
                fa_.play()
            if event.key == K_u:
                sol.play()
            if event.key == K_8:
                sol_.play()
            if event.key == K_i:
                la.play()
            if event.key == K_9:
                la_.play()
            if event.key == K_o:
                si.play()
            if event.key == K_p:
                do2.play()
                
pygame.quit()
